# bottle > 2022-08-01 12:40am
https://universe.roboflow.com/object-detection/bottle-sfn0j

Provided by Roboflow
License: CC BY 4.0

