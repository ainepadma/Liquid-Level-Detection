# cup Project > 2025-07-29 3:15pm
https://universe.roboflow.com/segong/cup-project

Provided by a Roboflow user
License: CC BY 4.0

