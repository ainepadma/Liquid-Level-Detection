# cup Project > 2025-07-24 2:16pm
https://universe.roboflow.com/segong/cup-project

Provided by a Roboflow user
License: CC BY 4.0

